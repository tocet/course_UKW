from time import sleep
from network import WLAN,STA_IF
from machine import reset,Pin
import uasyncio as asyncio
import gc

gc.collect()

def web_page(led_state):   
    html = """
    <html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
        <style>
            html {
                font-family: Arial;
                display: inline-block;
                margin: 0px auto;
                text-align: center;
            }

            .button {
                background-color: #ce1b0e;
                border: none;
                color: white;
                padding: 16px 40px;
                text-align: center;
                text-decoration: none;
                display: inline-block;
                font-size: 16px;
                margin: 4px 2px;
                cursor: pointer;
            }

            .button1 {
                background-color: #000000;
            }
        </style>
    </head>
    <body>
        <h2>RPi Pico W based web server</h2>
        <p>LED state: <strong>""" + led_state + """</strong></p>
        <p>
            <i class="fas fa-lightbulb fa-3x" style="color:#c81919;"></i>
            <a href=\"led_on\"><button class="button">LED ON</button></a>
        </p>
        <p>
            <i class="far fa-lightbulb fa-3x" style="color:#000000;"></i>
            <a href=\"led_off\"><button class="button button1">LED OFF</button></a>
        </p>
    </body>
    </html>"""
    return html


ssid = "ASUS"
password = "Doktorzec1"

led = Pin(15,Pin.OUT)
led_state = "LED is off"
onboard = Pin("LED",Pin.OUT,value = 0)

def wifi_connect():
    wlan = WLAN(STA_IF)
    wlan.active(True)
    wlan.connect(ssid,password)
    while wlan.isconnected() == False:
        print("Connection to " + ssid)
        sleep(1)
    print(wlan.ifconfig())
    print(f'Connected to {ssid} network, IP {wlan.ifconfig()[0]}')
   
async def handle_client(reader,writer):
    global led_state
    print("Client connected")
    request_line = await reader.readline()
    print("Request:",request_line)
    
    #skip header
    while await reader.readline() != b"\r\n":
        pass
    
    request = str(request_line)
    led_on = request.find('led_on')
    led_off = request.find('led_off')
    print('led on = ' + str(led_on))
    print('led off = ' + str(led_off))
    
    if led_on == 7:
        print("led on")
        led.value(1)
        led_state = "LED is ON"
    
    if led_off == 7:
        print("led off")
        led.value(0)
        led_state = "LED is OFF"
        
    response = web_page(led_state)
    writer.write('HTTP/1.0 200 OK\r\nContent-type: text/html\r\n\r\n')
    writer.write(response)
    
    await writer.drain()
    await writer.wait_closed()
    print("Client disconnected")
    
async def main():
    try:
        wifi_connect()
    except KeyboardInterrupt:
        reset()
        
    print("Starting webserver")
    asyncio.create_task(asyncio.start_server(handle_client, "0.0.0.0", 80))
 
    while True:
        onboard.on()
        print("server is still alive")
        await asyncio.sleep(0.25)
        onboard.off()
        await asyncio.sleep(5)

try:
    asyncio.run(main())
finally:
    asyncio.new_event_loop()